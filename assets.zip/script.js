/**
 * Дойняк — Riverside-style interactions
 */

document.addEventListener('DOMContentLoaded', () => {
  initHeader();
  initScrollReveal();
  initMobileNav();
  initProjectFilter();
  initContactForm();
  initFooterYear();
  initSmoothScroll();
  initNavActive();
});

function initHeader() {
  const header = document.getElementById('header');
  if (!header) return;
  const onScroll = () => {
    header.classList.toggle('scrolled', window.scrollY > 24);
  };
  window.addEventListener('scroll', onScroll, { passive: true });
  onScroll();
}

function initScrollReveal() {
  const reveals = document.querySelectorAll('.reveal');
  if (!reveals.length) return;

  const observer = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) entry.target.classList.add('active');
      });
    },
    { rootMargin: '0px 0px -48px 0px', threshold: 0.1 }
  );

  reveals.forEach((el) => observer.observe(el));
}

function initMobileNav() {
  const toggle = document.querySelector('.nav-toggle');
  const nav = document.querySelector('.nav');
  if (!toggle || !nav) return;

  const close = () => {
    nav.classList.remove('open');
    toggle.setAttribute('aria-expanded', 'false');
    toggle.setAttribute('aria-label', 'Открыть меню');
    document.body.style.overflow = '';
  };

  toggle.addEventListener('click', () => {
    const open = nav.classList.toggle('open');
    toggle.setAttribute('aria-expanded', String(open));
    toggle.setAttribute('aria-label', open ? 'Закрыть меню' : 'Открыть меню');
    document.body.style.overflow = open ? 'hidden' : '';
  });

  nav.querySelectorAll('a').forEach((link) => link.addEventListener('click', close));

  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') close();
  });
}

function initProjectFilter() {
  const buttons = document.querySelectorAll('.filter-btn');
  const cards = document.querySelectorAll('.card[data-type]');
  if (!buttons.length || !cards.length) return;

  buttons.forEach((btn) => {
    btn.addEventListener('click', () => {
      const filter = btn.dataset.filter;
      buttons.forEach((b) => b.classList.remove('active'));
      btn.classList.add('active');

      cards.forEach((card) => {
        const show = filter === 'all' || card.dataset.type === filter;
        card.classList.toggle('hidden', !show);
      });
    });
  });
}

function initContactForm() {
  const form = document.getElementById('contact-form');
  if (!form) return;

  const fields = {
    name: { el: form.querySelector('#name'), error: form.querySelector('#name-error') },
    contact: { el: form.querySelector('#contact-channel'), error: form.querySelector('#contact-error') },
    direction: { el: form.querySelector('#direction'), error: form.querySelector('#direction-error') },
    message: { el: form.querySelector('#message'), error: form.querySelector('#message-error') }
  };
  const status = document.getElementById('form-status');
  const labels = { site: 'Сайт', ads: 'Реклама', video: 'Видео', complex: 'Комплекс' };

  document.querySelectorAll('[data-direction]').forEach((link) => {
    link.addEventListener('click', () => {
      if (!fields.direction.el) return;
      fields.direction.el.value = link.dataset.direction || '';
    });
  });

  form.addEventListener('submit', (e) => {
    e.preventDefault();
    clearErrors(fields);
    if (status) status.textContent = '';
    let valid = true;
    let firstInvalid = null;

    if (!fields.name.el.value.trim()) {
      showError(fields.name, 'Введите имя');
      valid = false;
      firstInvalid = firstInvalid || fields.name.el;
    }

    if (!fields.contact.el.value.trim()) {
      showError(fields.contact, 'Укажите телефон или другой контакт');
      valid = false;
      firstInvalid = firstInvalid || fields.contact.el;
    }

    if (!fields.direction.el.value) {
      showError(fields.direction, 'Выберите направление');
      valid = false;
      firstInvalid = firstInvalid || fields.direction.el;
    }

    if (!fields.message.el.value.trim()) {
      showError(fields.message, 'Опишите задачу');
      valid = false;
      firstInvalid = firstInvalid || fields.message.el;
    } else if (fields.message.el.value.trim().length < 10) {
      showError(fields.message, 'Минимум 10 символов');
      valid = false;
      firstInvalid = firstInvalid || fields.message.el;
    }

    if (!valid) {
      firstInvalid.focus();
      return;
    }

    const direction = labels[fields.direction.el.value] || fields.direction.el.value;
    const body = [
      `Имя: ${fields.name.el.value.trim()}`,
      `Контакт: ${fields.contact.el.value.trim()}`,
      `Направление: ${direction}`,
      '',
      fields.message.el.value.trim()
    ].join('\n');
    const mailto = `mailto:hello@vitalikdoyniak.com?subject=${encodeURIComponent('Проект VD Group — ' + direction)}&body=${encodeURIComponent(body)}`;

    if (status) {
      status.textContent = 'Форма не отправляет заявку на сервер. Откроется письмо в почтовой программе. Если оно не открылось, напишите на hello@vitalikdoyniak.com или в Telegram.';
    }
    window.location.href = mailto;
  });

  Object.values(fields).forEach(({ el, error }) => {
    if (!el) return;
    el.addEventListener('input', () => {
      el.classList.remove('error');
      if (error) error.textContent = '';
    });
    el.addEventListener('change', () => {
      el.classList.remove('error');
      if (error) error.textContent = '';
    });
  });
}

function showError(field, message) {
  field.el.classList.add('error');
  if (field.error) field.error.textContent = message;
}

function clearErrors(fields) {
  Object.values(fields).forEach(({ el, error }) => {
    el.classList.remove('error');
    if (error) error.textContent = '';
  });
}

function initFooterYear() {
  const el = document.getElementById('year');
  if (el) el.textContent = String(new Date().getFullYear());
}

function initSmoothScroll() {
  document.querySelectorAll('a[href^="#"]').forEach((anchor) => {
    const href = anchor.getAttribute('href');
    if (!href || href === '#') return;

    anchor.addEventListener('click', (e) => {
      const target = document.querySelector(href);
      if (!target) return;
      e.preventDefault();
      const top = target.getBoundingClientRect().top + window.scrollY - 64;
      window.scrollTo({ top, behavior: 'smooth' });
    });
  });
}

function initNavActive() {
  const sections = document.querySelectorAll('section[id]');
  const links = document.querySelectorAll('.nav-list a');
  if (!sections.length || !links.length) return;

  const observer = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        if (!entry.isIntersecting) return;
        links.forEach((link) => {
          link.classList.toggle('active', link.getAttribute('href') === `#${entry.target.id}`);
        });
      });
    },
    { rootMargin: '-40% 0px -50% 0px' }
  );

  sections.forEach((section) => observer.observe(section));
}
